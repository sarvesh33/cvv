console.log('Order Module Started!');
class Order {
    constructor(public orderId?:number, public orderDate?: Date, public quantity?: number, public orderInfo?:string) {
        console.log("Order class constructor executed!");
    }
    // getOrderInformation(): string {
    //     return `Order Id is ${this.orderId} and your purchase order is ${this.orderDate} and quantity is ${this.quantity}!`;
    // }
}
export default Order;
console.log('Order Module Ended!');