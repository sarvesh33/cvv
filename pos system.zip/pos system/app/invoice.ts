console.log('Invoice Module Started!');
import Order from "./order";

class Invoice extends Order{
    constructor(){
        super();
        console.log("Invoice class constructor executed!");
    }
    invoiceId:number;
    invoiceamount:number;
    invoicedate:Date;
}
export default Invoice;
console.log('Invoice Module Ended!');