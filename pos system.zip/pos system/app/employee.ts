console.log('Employee Module Started!');
import Person from "./person";

class Employee extends Person{
    constructor(){
        super();
        console.log("Employee class constructor executed!");
    }
    employeeId:number;
}
export default Employee;
console.log('Employee Module Ended!');