// console.log('Product Module Started!');
// abstract class Product {
//     constructor(public productId?: number, public type?: string, public description?: string) {
//         console.log("Product class constructor executed!");
//     }
//     getProductInformation(): string {
//         return `Product Id is ${this.productId} and type is ${this.type} this is description ${this.description}!`;
//     }
// }
// export default Product;
// console.log('Product Module Ended!');
console.log('Product Module Started!');
import Category from "./category";

class Product extends Category{
    constructor(){
        super();
        console.log("Product class constructor executed!");
    }
    productId:number;
    productType: string;
    unitPrice:number;
    availableStock:number;
    descriptionn:string;
}
export default Product;
console.log('Product Module Ended!');