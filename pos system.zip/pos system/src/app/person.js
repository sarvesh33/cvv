"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
console.log('Person Module Started!');
class Person {
    firstName;
    lastName;
    city;
    constructor(firstName, lastName, city) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.city = city;
        console.log("Person class constructor executed!");
    }
    getPersonInformation() {
        return `Person name is ${this.firstName} ${this.lastName} lives in city ${this.city}!`;
    }
}
exports.default = Person;
console.log('Person Module Ended!');
//# sourceMappingURL=person.js.map