"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
console.log('Shipper Module Started!');
const person_1 = require("./person");
class Shipper extends person_1.default {
    constructor() {
        super();
        console.log("Shipper class constructor executed!");
    }
    shipperId;
}
exports.default = Shipper;
console.log('Shipper Module Ended!');
//# sourceMappingURL=Shipper.js.map