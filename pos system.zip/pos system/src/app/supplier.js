"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
console.log('Supplier Module Started!');
const person_1 = require("./person");
class Supplier extends person_1.default {
    constructor() {
        super();
        console.log("Supplier class constructor executed!");
    }
    supplierId;
}
exports.default = Supplier;
console.log('Supplier Module Ended!');
//# sourceMappingURL=supplier.js.map