console.log('Customer Module Started!');
import Person from "./person";

class Customer extends Person{
    constructor(){
        super();
        console.log("Customer class constructor executed!");
    }
    customerId:number;
}

export default Customer;

console.log('Customer Module Ended!');