"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
console.log('Category Module Started!');
class Category {
    categoryId;
    type;
    description;
    constructor(categoryId, type, description) {
        this.categoryId = categoryId;
        this.type = type;
        this.description = description;
        console.log("Category class constructor executed!");
    }
    getCategoryInformation() {
        return `Category Id is ${this.categoryId} and type is ${this.type} this is description ${this.description}!`;
    }
}
exports.default = Category;
console.log('Category Module Ended!');
//# sourceMappingURL=category.js.map