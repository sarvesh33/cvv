console.log('Person Module Started!');
abstract class Person {
    constructor(public firstName?: string, public lastName?: string, public city?: string) {
        console.log("Person class constructor executed!");
    }
    getPersonInformation(): string {
        return `Person name is ${this.firstName} ${this.lastName} lives in city ${this.city}!`;
    }
}
export default Person;
console.log('Person Module Ended!');