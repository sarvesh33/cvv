"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
// console.log('Product Module Started!');
// abstract class Product {
//     constructor(public productId?: number, public type?: string, public description?: string) {
//         console.log("Product class constructor executed!");
//     }
//     getProductInformation(): string {
//         return `Product Id is ${this.productId} and type is ${this.type} this is description ${this.description}!`;
//     }
// }
// export default Product;
// console.log('Product Module Ended!');
console.log('Product Module Started!');
const category_1 = require("./category");
class Product extends category_1.default {
    constructor() {
        super();
        console.log("Product class constructor executed!");
    }
    productId;
    productType;
    unitPrice;
    availableStock;
    descriptionn;
}
exports.default = Product;
console.log('Product Module Ended!');
//# sourceMappingURL=product.js.map