"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
console.log('Invoice Module Started!');
const order_1 = require("./order");
class Invoice extends order_1.default {
    constructor() {
        super();
        console.log("Invoice class constructor executed!");
    }
    invoiceId;
    invoiceamount;
    invoicedate;
}
exports.default = Invoice;
console.log('Invoice Module Ended!');
//# sourceMappingURL=invoice.js.map