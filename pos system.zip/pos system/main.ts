console.log('Main Module Started!');

import CommonRepository from "./app/common-repositort";
import SynechronCrudRepository from "./app/synechron-crud";
import Customer from "./app/customer";
import Employee from "./app/employee";
import Category from "./app/category";
import Product from "./app/product";
import Shipper from "./app/Shipper";
import Supplier from "./app/supplier";
import Order from "./app/order";
import Invoice from "./app/invoice";

const customer1:Customer=new Customer();
customer1.customerId=1001;
customer1.firstName="Sarvesh";
customer1.lastName="Muttepwar";
customer1.city="pune";

const employee1:Employee=new Employee();
employee1.employeeId=2001;
employee1.firstName="Rajesh";
employee1.lastName="Shinde";
employee1.city="Latur";

const shipper1:Shipper= new Shipper();
shipper1.shipperId=2001;
shipper1.firstName="Hari";
shipper1.lastName="Patil";
shipper1.city="Pune";

const supplier1:Supplier= new Supplier();
supplier1.supplierId=2001;
supplier1.firstName="Nikhil";
supplier1.lastName="Kamat";
supplier1.city="Hyderabad";

const category1:Category= new Category();
category1.categoryId=4000;
category1.type="Clothing";
category1.description="This is the clothes category";

const product1:Product= new Product();
product1.productId=4001;
product1.productType="jeans";
product1.descriptionn="This is Denium jeans";
product1.unitPrice=800;

const order1:Order= new Order();
order1.orderId=565648;
order1.orderDate=new Date;
order1.orderInfo="your order has placed successfully";
order1.quantity=2;

const invoice1:Invoice= new Invoice();
invoice1.invoiceId=49999;
invoice1.invoicedate=new Date;
invoice1.invoiceamount= (order1.quantity * product1.unitPrice);

console.log(`\t \n \n \n \n`)
console.log(`Customer Details- \n \tCustomerId- ${customer1.customerId}  \n \tName-${customer1.firstName} ${customer1.lastName}\n \tAddress- ${customer1.city} `);

console.log(`Employee Details- \n \tEmployeeId- ${employee1.employeeId}  \n \tName-${employee1.firstName} ${employee1.lastName}\n \tAddress- ${employee1.city} `);

console.log(`Shipper Details- \n \tShipperId- ${shipper1.shipperId}  \n \tName-${shipper1.firstName} ${shipper1.lastName}\n \tAddress- ${shipper1.city} `);

console.log(`Supplier Details- \n \tSupplierId- ${supplier1.supplierId}  \n \tName-${supplier1.firstName} ${supplier1.lastName}\n \tAddress- ${supplier1.city} `);

console.log(`Category Details- \n \tCategoryId-${category1.categoryId} \n \tCategory type-${category1.type}\n \tDescription-${category1.description}`);

console.log(`Product Details- \n \tProductId-${product1.productId} \n \tProduct type-${product1.productType}\n \tDescription-${product1.descriptionn}\n\tunit price-${product1.unitPrice}`);

console.log(`Order Details- \n \tOrderId-${order1.orderId} \n \tDate-${order1.orderDate}\n\tQuantity-${order1.quantity}\n\tOrderInfo${order1.orderInfo}`);

console.log(`Invoice Detail- \n \tInvoiceID-${invoice1.invoiceId} \n \tDate-${invoice1.invoicedate}\n \tInvoice Amount-${invoice1.invoiceamount}`)





