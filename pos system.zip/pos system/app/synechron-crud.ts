import CommonCrud from "./common-repositort";

export default class SynechronCrud<T> implements CommonCrud<T>{
    private _localDb: Array<T> = new Array<T>();
    getAll(): T[] {
        return this._localDb;
    }
    getDetails(id: number): T {
        return this._localDb[0];
    }
    insert(item: T): void {
        this._localDb.push(item);
    }
    update(item: T): void {
        throw new Error("Method not implemented.");
    }
    delete(id: number): void {
        throw new Error("Method not implemented.");
    }
}
