export default interface CommonCrud<T> {
    getAll(): T[];
    getDetails(id: number): T;
    insert(item: T): void;
    update(item: T): void;
    delete(id: number): void;
}