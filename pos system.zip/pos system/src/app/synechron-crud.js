"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class SynechronCrud {
    _localDb = new Array();
    getAll() {
        return this._localDb;
    }
    getDetails(id) {
        return this._localDb[0];
    }
    insert(item) {
        this._localDb.push(item);
    }
    update(item) {
        throw new Error("Method not implemented.");
    }
    delete(id) {
        throw new Error("Method not implemented.");
    }
}
exports.default = SynechronCrud;
//# sourceMappingURL=synechron-crud.js.map