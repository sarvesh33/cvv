console.log('Shipper Module Started!');
import Person from "./person";

class Shipper extends Person{
    constructor(){
        super();
        console.log("Shipper class constructor executed!");
    }
    shipperId:number;
}


export default Shipper;

console.log('Shipper Module Ended!');