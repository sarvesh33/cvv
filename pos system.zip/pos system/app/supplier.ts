console.log('Supplier Module Started!');
import Person from "./person";

class Supplier extends Person{
    constructor(){
        super();
        console.log("Supplier class constructor executed!");
    }
    supplierId:number;
}


export default Supplier;

console.log('Supplier Module Ended!');