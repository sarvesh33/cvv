console.log('Category Module Started!');
class Category {
    constructor(public categoryId?: number, public type?: string, public description?: string) {
        console.log("Category class constructor executed!");
    }
    getCategoryInformation(): string {
        return `Category Id is ${this.categoryId} and type is ${this.type} this is description ${this.description}!`;
    }
}
export default Category;
console.log('Category Module Ended!');