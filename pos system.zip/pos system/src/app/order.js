"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
console.log('Order Module Started!');
class Order {
    orderId;
    orderDate;
    quantity;
    orderInfo;
    constructor(orderId, orderDate, quantity, orderInfo) {
        this.orderId = orderId;
        this.orderDate = orderDate;
        this.quantity = quantity;
        this.orderInfo = orderInfo;
        console.log("Order class constructor executed!");
    }
}
exports.default = Order;
console.log('Order Module Ended!');
//# sourceMappingURL=order.js.map